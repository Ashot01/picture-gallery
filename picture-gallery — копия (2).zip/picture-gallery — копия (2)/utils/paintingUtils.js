const paintings = require("../data/paintingsData");

// Поиск по тексту в полях title, artist, description
const applySearch = (paintings, searchTerm) => {
    if (!searchTerm) return paintings;
    return paintings.filter(painting => painting.title.toLowerCase().includes(searchTerm) || painting.artist.toLowerCase().includes(searchTerm) || painting.description.toLowerCase().includes(searchTerm));
};

// Применение фильтров
const applyFilters = (paintings, filters) => {
    let filtered = [...paintings];
    
    // Фильтрация по жанру
    if (filters.genre) {
        const genreTerm = filters.genre.toLowerCase();
        filtered = filtered.filter(painting => painting.genre.some(g => g.toLowerCase().includes(genreTerm)));
    }
    if (filters.artist) {
        const artistTerm = filters.artist.toLowerCase();
        filtered = filtered.filter(painting => painting.artist.toLowerCase().includes(artistTerm));
    }
    if (filters.isFeatured) {
        const isFeatured = filters.isFeatured === true;
        filtered = filtered.filter(painting => painting.isFeatured === isFeatured);
    }
    if (filters.minYear) {
        const minYear = parseInt(filters.minYear);
        filtered = filtered.filter(painting => painting.year >= minYear);
    }
    if (filters.maxYear) {
        const maxYear = parseInt(filters.maxYear);
        filtered = filtered.filter(painting => painting.year <= maxYear);
    }
    if (filters.minPrace) {
        const minPrace = parseInt(filters.minPrace);
        filtered = filtered.filter(painting => painting.year >= minPrace);
    }
    if (filters.maxPrace) {
        const maxPrace = parseInt(filters.maxPrace);
        filtered = filtered.filter(painting => painting.year <= maxPrace);
    }
    return filtered;
};

// Применение пагинации
const applyPagination = (paintings, page, limit) => {
    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const startIndex = (pageNum - 1) * limitNum;
    const endIndex = startIndex + limitNum;
  
    return {
        data: paintings.slice(startIndex, endIndex), // Выборка данных для текущей страницы
        pagination: {
            currentPage: pageNum,
            totalPages: Math.ceil(paintings.length / limitNum),
            itemsPerPage: limitNum,
            totalItems: paintings.length,
            hasNextPage: pageNum < Math.ceil(paintings.length / limitNum),
            hasPrevPage: pageNum > 1
        }
    };
};

const applySorting = (paintings, sortBy, sortOrder = 'asc') => {
    if (!sortBy) return paintings

    const sorted = [...paintings]
    const direction = sortOrder.toLowerCase() === 'desc' ? -1 : 1

    sorted.sort((a, b) => {
        let valueA, valueB

        if (sortBy === 'dimensions.width'){
            valueA = a.dimensions?.width
            valueB = b.dimensions?.width
        } else if (sortBy === 'dimensions.height') {
            valueA = a.dimensions?.height
            valueB = b.dimensions?.height
        } else {
            valueA = a[sortBy]
            valueB = b[sortBy]
        }

        if (typeof valueA === 'string' && typeof valueB === 'string') {
            return direction * valueA.localeCompare(valueB)
        }

        return direction * (valueA - valueB)
    })

    return sorted
}





module.exports = {
    applySearch,
    applyFilters,
    applyPagination
};
