// Middleware-функция для логирования запросов
const logger = (req, res, next) => {
  const time = new Date().toLocaleString();
  console.log(`${time} - ${req.method} request to ${req.originalUrl}`);
  next(); // Передаем управление следующему middleware/роуту
};

module.exports = logger;
