const express = require('express');
const router = express.Router();
// Импортируем методы контроллера
const {
    getPaintings,
    getPaintingById,
    getPaintingsByGenre,
    getFeaturedPaintings
} = require('../controllers/paintingController');
const validateQueryParams = require('../middleware/validateQueryParams');

// GET /api/paintings — все картины, с опциональной фильтрацией по ?featured=true
router.get('/', validateQueryParams, getPaintings);

// GET /api/paintings/featured — только featured картины
router.get('/featured', getFeaturedPaintings);

// GET /api/paintings/genre/:genre — фильтрация картин по жанру
router.get('/genre/:genre', getPaintingsByGenre);

// GET /api/paintings/:id — получение картины по ID
router.get('/:id', getPaintingById);

// Экспортируем роутер для подключения в index.js
module.exports = router;
